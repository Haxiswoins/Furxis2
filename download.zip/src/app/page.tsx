'use client';

import { LandingPageClient } from '@/components/landing-client';

export default function Home() {
  return (
    <>
      <LandingPageClient />
    </>
  );
}
