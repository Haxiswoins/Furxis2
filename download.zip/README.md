# Firebase Studio

This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.

To sync your local changes to your GitHub repository, you can run the `SYNC_TO_GIT.sh` script.
